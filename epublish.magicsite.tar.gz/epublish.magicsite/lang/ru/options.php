<?php
$MESS["EPUBLISH_MAGICSITE_TAB_SETTINGS"] = 'Основные настройки';
$MESS["EPUBLISH_MAGICSITE_URL_TITLE"] = 'Адрес сайта в ИС MagicSite';
$MESS["EPUBLISH_MAGICSITE_URL_ERROR"] = 'Не верное значение в поле "Адрес сайта в ИС MagicSite"';
