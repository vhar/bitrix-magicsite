<?php
$arModuleVersion = [
	"VERSION" => "1.0.2",
	"VERSION_DATE" => "2022-11-17 20:15:00"
];
