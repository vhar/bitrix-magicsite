<?php
$arModuleVersion = [
	"VERSION" => "1.0.1",
	"VERSION_DATE" => "2021-08-19 14:00:00"
];
